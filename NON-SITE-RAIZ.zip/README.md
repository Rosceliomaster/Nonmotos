# NON Moto Peças, Mecânica & Preparações

Site estático pronto. **Todas as imagens já estão incluídas** em `assets/img/`.

## Deploy na Vercel

1. Extraia o ZIP **na raiz do repositório**. O repo deve ficar assim:

```text
index.html
assets/img/ (5 imagens)
assets/js/main.js
robots.txt
sitemap.xml
README.md
.gitignore
```

2. **Apague as pastas antigas** `non-cardoso-motos/` e `nonmotos-vercel-pronto/` do repositório.
3. Commit + push.
4. Vercel → **Configurações do Projeto → Geral**:
   - **Diretório Raiz:** `./` (raiz)
   - **Framework Preset:** Other
   - **Comando de Build:** vazio
   - **Diretório de Saída:** vazio
5. **Implantações → ⋯ → Reimplantar**.

## Contatos

- WhatsApp: (11) 94039-7294
- Instagram: @non_motos_
- Google: share.google/2DTcoq9zr0nIPFWyP
- Avaliar: g.page/r/CRJEW915KdMJEBM/review
